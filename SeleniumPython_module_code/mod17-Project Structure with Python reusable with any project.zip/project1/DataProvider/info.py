'''
Created on 09-Jun-2020
@author: jaspreet
'''
browser1 = 'chrome'
browser2 = 'ie'

def data():
    data = [1,2,3,4,5,6]
    return data

def add(num1,num2):
    result= num1+num2
    return result