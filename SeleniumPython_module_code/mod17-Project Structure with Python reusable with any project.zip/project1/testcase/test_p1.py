'''
Created on 09-Jun-2020

@author: jaspreet
'''
class TestP1:
    def test_1(self):
        print("i am in test_p1")
        assert True,"Passing Test p1"