'''
Created on 09-Jun-2020

@author: jaspreet
'''
class TestP2:
    def test_1(self):
        print("i am in test_p2")
        assert True,"Passing Test p2"